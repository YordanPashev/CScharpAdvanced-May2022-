﻿namespace FolderSize
{
    internal class StreamWrite
    {
    }
}