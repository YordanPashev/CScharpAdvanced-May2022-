﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorsAndComparators
{
    public class Library : IEnumerable<string>
    {
        private List<Book> books;

        public Library(params Book[] books)
        {
            this.books = new List<Book>(books);
        }

        public IEnumerator<string> GetEnumerator()
        {
            return new LibraryIterator(this.books);
        }

        IEnumerator IEnumerable.GetEnumerator() => this.GetEnumerator();

        private class LibraryIterator : IEnumerator<string>
        {
            private List<Book> books;
            private int currentIndex;

            public LibraryIterator(List<Book> books)
            {
                this.books = new List<Book>(books);
                currentIndex = -1;
            }
            public void Dispose() { }

            public bool MoveNext()
            {
                currentIndex++;
                if (currentIndex < books.Count)
                {
                    return true;
                }

                return false;
            }

            public void Reset() { }

            public string Current => this.books[currentIndex].Title;

            object IEnumerator.Current => this.Current;

        }
    }
}


